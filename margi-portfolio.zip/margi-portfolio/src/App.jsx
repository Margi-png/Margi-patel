import { BrowserRouter as Router, Routes, Route, Link } from "react-router-dom";
import { Home } from "./pages/Home";
import { About } from "./pages/About";
import { Articles } from "./pages/Articles";
import { Blogs } from "./pages/Blogs";
import { PromoWriting } from "./pages/PromoWriting";
import { Copywriting } from "./pages/Copywriting";
import { Contact } from "./pages/Contact";

export default function App() {
  return (
    <Router>
      <div className="min-h-screen bg-white text-gray-800">
        <nav className="bg-gray-900 text-white p-4 shadow-md">
          <div className="container mx-auto flex gap-6">
            <Link to="/">Home</Link>
            <Link to="/about">About</Link>
            <Link to="/articles">Articles</Link>
            <Link to="/blogs">Blogs</Link>
            <Link to="/promo-writing">Promo Writing</Link>
            <Link to="/copywriting">Copywriting</Link>
            <Link to="/contact">Contact</Link>
          </div>
        </nav>
        <main className="container mx-auto p-6">
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/about" element={<About />} />
            <Route path="/articles" element={<Articles />} />
            <Route path="/blogs" element={<Blogs />} />
            <Route path="/promo-writing" element={<PromoWriting />} />
            <Route path="/copywriting" element={<Copywriting />} />
            <Route path="/contact" element={<Contact />} />
          </Routes>
        </main>
      </div>
    </Router>
  );
}
